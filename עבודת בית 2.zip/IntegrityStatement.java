public class IntegrityStatement {

	public static String signature() {
		// change the returned value to your name/s, for example: "John Doe" if submitting alone, or "John Doe and Ploni Almoni" if submitted in pair
		return "John Doe";
	}
	
}
